import main from "./script/view/main.js"
import "./style/style.css"

main();